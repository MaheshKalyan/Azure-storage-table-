﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.Azure;
using System.Configuration;
using System.Windows;
using System.Windows.Controls;

namespace AzureTableApp
{

    public class AzureTable
    {
        static CloudStorageAccount account = CloudStorageAccount.Parse(ConfigurationSettings.AppSettings["StorageConnectionString"]);
        static CloudTableClient cloudTableClient = account.CreateCloudTableClient();

        public void CreateAzureTable(String tableName)
        {
            CloudTable azureTable = cloudTableClient.GetTableReference(tableName);
            if (azureTable.CreateIfNotExists())
                MessageBox.Show(string.Format("{0}  is created!!! ", azureTable.Name));
            else
                MessageBox.Show(string.Format("{0} is already there!!! ", azureTable.Name));
        }

        public void AddDataIntoAzureTable(string tableName, Product prodEntity)
        {
            prodEntity.RowKey = prodEntity.ID + "" + prodEntity.Name;
            prodEntity.PartitionKey = prodEntity.Category;

            TableOperation tableOperation = TableOperation.Insert(prodEntity);
            CloudTable azureTable = cloudTableClient.GetTableReference(tableName);
            azureTable.Execute(tableOperation);
            MessageBox.Show(string.Format("Data added to {0}\nID:{1}, Name:{2}, Price:{3}, Category:{4}", tableName, prodEntity.ID, prodEntity.Name, prodEntity.Price, prodEntity.Category));
        }

        public void tableData(string tableName, ListBox listBox)
        {
            CloudTable azureTable = cloudTableClient.GetTableReference(tableName);
            if (azureTable.Exists())
            {
                TableQuery<Product> query = new TableQuery<Product>();
                var prodEntities = azureTable.ExecuteQuery(query);
                if (prodEntities.Count() > 0) listBox.Items.Clear();
                foreach (var entity in prodEntities)
                {
                    listBox.Items.Add(entity.ID + " " + entity.Name + " " + entity.Price + " " + entity.Category);
                }
            }
            else
            {
                MessageBox.Show(tableName + " doesn't Exists!!!");
            }
        }

    }
}
